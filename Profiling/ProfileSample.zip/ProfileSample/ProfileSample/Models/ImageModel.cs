﻿using System.Collections.Generic;

namespace ProfileSample.Models
{
    public class ImageModel
    {
        public string Name { get; set; }

        public byte[] Data { get; set; } 
    }
}